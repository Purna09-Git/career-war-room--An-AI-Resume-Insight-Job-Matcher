// Configuration
const BACKEND_URL = window.location.origin;
const API_URL = `${BACKEND_URL}/api`;

// State
let currentAuthMode = 'login';
let analysisData = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initializeFileUpload();
    initializeAuthForm();
});

// File Upload Handlers
function initializeFileUpload() {
    const fileInput = document.getElementById('fileInput');
    const uploadButton = document.getElementById('uploadButton');
    const fileUploadZone = document.getElementById('fileUploadZone');

    // Button click
    uploadButton.addEventListener('click', (e) => {
        e.stopPropagation();
        fileInput.click();
    });

    // Zone click
    fileUploadZone.addEventListener('click', () => {
        fileInput.click();
    });

    // File selection
    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            handleFileUpload(file);
        }
    });

    // Drag and drop
    fileUploadZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        fileUploadZone.classList.add('dragging');
    });

    fileUploadZone.addEventListener('dragleave', () => {
        fileUploadZone.classList.remove('dragging');
    });

    fileUploadZone.addEventListener('drop', (e) => {
        e.preventDefault();
        fileUploadZone.classList.remove('dragging');
        const file = e.dataTransfer.files[0];
        if (file) {
            handleFileUpload(file);
        }
    });
}

// Handle File Upload
async function handleFileUpload(file) {
    // Validate file type
    const validTypes = ['.pdf', '.docx', '.txt'];
    const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
    
    if (!validTypes.includes(fileExtension)) {
        showError('Unsupported file type. Please upload PDF, DOCX, or TXT file.');
        return;
    }

    // Show loading
    showLoading();

    try {
        const formData = new FormData();
        formData.append('file', file);

        const response = await fetch(`${API_URL}/analyze-resume`, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.detail || 'Failed to analyze resume');
        }

        const data = await response.json();
        analysisData = data;
        showDashboard(data);
    } catch (error) {
        console.error('Error:', error);
        showError(error.message || 'Strategic analysis failed. Intelligence link may be offline.');
        hideLoading();
    }
}

// Show/Hide Loading
function showLoading() {
    document.getElementById('fileUploadZone').style.display = 'none';
    document.getElementById('loadingState').style.display = 'flex';
    document.getElementById('errorMessage').style.display = 'none';
}

function hideLoading() {
    document.getElementById('fileUploadZone').style.display = 'flex';
    document.getElementById('loadingState').style.display = 'none';
}

// Show Error
function showError(message) {
    const errorEl = document.getElementById('errorMessage');
    errorEl.textContent = message;
    errorEl.style.display = 'flex';
}

// Show Dashboard
function showDashboard(data) {
    document.getElementById('landingPage').style.display = 'none';
    document.getElementById('dashboardPage').style.display = 'block';
    renderDashboard(data);
}

// Render Dashboard
function renderDashboard(data) {
    const { resume, jobs, insights } = data;

    const html = `
        <div class="dashboard-container">
            <!-- Dashboard Header -->
            <div class="dashboard-header">
                <div class="dashboard-header-left">
                    <div class="dashboard-badges">
                        <span class="badge-confidential">Confidential</span>
                        <span class="badge-deployment">Deployment: Active</span>
                    </div>
                    <h1 class="dashboard-main-title">Strategic Profile: ${resume.name}</h1>
                    <p class="dashboard-subtitle">Intelligence analysis completed via <span class="text-blue">NEXT STEP v2.5</span></p>
                </div>
                <button class="dashboard-reset-btn" onclick="resetDashboard()">
                    <i class="fa-solid fa-arrow-rotate-left"></i>
                    New Tactical Upload
                </button>
            </div>

            <!-- KPI Grid -->
            <div class="kpi-grid">
                <div class="kpi-card kpi-border-slate">
                    <p class="kpi-label">Combat Readiness</p>
                    <p class="kpi-value">${insights.score}<span class="kpi-unit">%</span></p>
                    <div class="kpi-progress-bar">
                        <div class="kpi-progress-fill" style="width: ${insights.score}%"></div>
                    </div>
                </div>
                <div class="kpi-card kpi-border-blue">
                    <p class="kpi-label">Market Position</p>
                    <p class="kpi-value-text kpi-value-blue">${insights.marketDemand}</p>
                    <p class="kpi-status">Field Intel Status</p>
                </div>
                <div class="kpi-card kpi-border-indigo">
                    <p class="kpi-label">Weaponry (Skills)</p>
                    <p class="kpi-value-text kpi-value-indigo">${resume.skills.length}</p>
                    <p class="kpi-status">Active Proficiencies</p>
                </div>
                <div class="kpi-card kpi-border-emerald">
                    <p class="kpi-label">Match Potential</p>
                    <p class="kpi-value-text kpi-value-emerald">${jobs.length}</p>
                    <p class="kpi-status">High Probability Targets</p>
                </div>
            </div>

            <!-- Main Content Grid -->
            <div class="dashboard-grid">
                <!-- Left Column -->
                <div class="dashboard-left">
                    <!-- Experience Section -->
                    <section class="dashboard-card">
                        <h2 class="dashboard-section-title">
                            <i class="fa-solid fa-timeline text-blue"></i>
                            Operational History
                        </h2>
                        <div class="experience-list">
                            ${resume.experience.map((exp, i) => `
                                <div class="experience-item">
                                    <div class="experience-timeline">
                                        <div class="experience-badge ${i === resume.experience.length - 1 ? 'experience-badge-current' : ''}">${i + 1}</div>
                                        ${i < resume.experience.length - 1 ? '<div class="experience-line"></div>' : ''}
                                    </div>
                                    <div class="experience-content">
                                        <h3 class="experience-title">${exp.title}</h3>
                                        <p class="experience-company">${exp.company} \u2022 ${exp.duration}</p>
                                        <div class="experience-highlights">
                                            ${exp.highlights.slice(0, 4).map(h => `
                                                <div class="experience-highlight">
                                                    <i class="fa-solid fa-check"></i>
                                                    ${h}
                                                </div>
                                            `).join('')}
                                        </div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </section>
                </div>

                <!-- Right Column -->
                <div class="dashboard-right">
                    <!-- Campaign Roadmap -->
                    <section class="campaign-card">
                        <h2 class="campaign-title">
                            <i class="fa-solid fa-map-location-dot"></i>
                            Campaign Roadmap
                        </h2>
                        <div class="campaign-recommendations">
                            ${insights.topRecommendations.map((rec, i) => `
                                <div class="campaign-item">
                                    <div class="campaign-number">${i + 1}</div>
                                    <p class="campaign-text">${rec}</p>
                                </div>
                            `).join('')}
                        </div>
                        
                        <div class="campaign-gaps">
                            <h3 class="campaign-gaps-title">Vulnerabilities (Gaps)</h3>
                            <div class="campaign-gaps-list">
                                ${insights.gapAnalysis.map(gap => `
                                    <span class="campaign-gap-tag">${gap}</span>
                                `).join('')}
                            </div>
                        </div>
                    </section>

                    <!-- Skills Section -->
                    <section class="dashboard-card">
                        <h2 class="dashboard-section-title">
                            <i class="fa-solid fa-screwdriver-wrench text-blue"></i>
                            Tool Inventory
                        </h2>
                        <div class="skills-list">
                            ${resume.skills.map(skill => `
                                <span class="skill-tag">${skill}</span>
                            `).join('')}
                        </div>
                    </section>
                </div>
            </div>

            <!-- Job Recommendations -->
            <section class="jobs-section">
                <div class="jobs-header">
                    <h2 class="jobs-title">Identified Targets</h2>
                    <div class="jobs-status">
                        <i class="fa-solid fa-satellite"></i>
                        Live Match Engine
                    </div>
                </div>
                <div class="jobs-grid">
                    ${jobs.map(job => `
                        <div class="job-card">
                            <div class="job-card-header">
                                <div class="job-icon">
                                    <i class="fa-solid fa-building-shield"></i>
                                </div>
                                <div class="job-match">
                                    <span class="job-match-score">${job.matchScore}<span class="job-match-unit">%</span></span>
                                    <p class="job-match-label">Confidence</p>
                                </div>
                            </div>
                            
                            <h3 class="job-title">${job.title}</h3>
                            <p class="job-company">${job.company} \u2022 ${job.location}</p>
                            
                            <div class="job-content">
                                <div class="job-reason">
                                    <p class="job-reason-text">"${job.reason}"</p>
                                </div>
                                <div class="job-skills">
                                    ${job.skillsFound.slice(0, 3).map(s => `
                                        <span class="job-skill-tag">\u2713 ${s}</span>
                                    `).join('')}
                                </div>
                            </div>

                            <div class="job-footer">
                                <span class="job-salary">${job.salaryEstimate || '$120k - $150k'}</span>
                                <button class="job-engage-btn">Engage</button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </section>
        </div>
    `;

    document.getElementById('dashboardPage').innerHTML = html;
}

// Reset Dashboard
function resetDashboard() {
    analysisData = null;
    document.getElementById('landingPage').style.display = 'block';
    document.getElementById('dashboardPage').style.display = 'none';
    document.getElementById('fileUploadZone').style.display = 'flex';
    document.getElementById('loadingState').style.display = 'none';
    document.getElementById('errorMessage').style.display = 'none';
    document.getElementById('fileInput').value = '';
}

// Auth Modal Handlers
function openAuthModal(mode) {
    currentAuthMode = mode;
    const modal = document.getElementById('authModal');
    const cardTitle = document.getElementById('authCardTitle');
    const nameField = document.getElementById('nameField');
    const submitText = document.getElementById('submitText');
    const toggleBtn = document.getElementById('authToggle');

    if (mode === 'login') {
        cardTitle.textContent = 'Commander Login';
        nameField.style.display = 'none';
        submitText.textContent = 'Initialize Session';
        toggleBtn.textContent = 'No Credentials? Create Command';
    } else {
        cardTitle.textContent = 'New Deployment';
        nameField.style.display = 'block';
        submitText.textContent = 'Deploy Assets';
        toggleBtn.textContent = 'Existing Commander? Authenticate';
    }

    modal.style.display = 'flex';
}

function closeAuthModal() {
    document.getElementById('authModal').style.display = 'none';
}

function toggleAuthMode() {
    currentAuthMode = currentAuthMode === 'login' ? 'signup' : 'login';
    openAuthModal(currentAuthMode);
}

function initializeAuthForm() {
    const authForm = document.getElementById('authForm');
    authForm.addEventListener('submit', (e) => {
        e.preventDefault();
        // Mock authentication
        alert('Authentication system is for demonstration purposes only.');
        closeAuthModal();
    });
}
