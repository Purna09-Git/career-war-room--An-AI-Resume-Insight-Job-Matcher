#!/bin/bash

# AI Resume Insight & Job Matcher - Startup Script

echo "================================================"
echo "AI Resume Insight & Job Matcher"
echo "Starting servers..."
echo "================================================"

# Check if MongoDB is running
if ! pgrep -x "mongod" > /dev/null
then
    echo "⚠️  Warning: MongoDB doesn't appear to be running"
    echo "   Please start MongoDB first:"
    echo "   - macOS/Linux: sudo systemctl start mongod"
    echo "   - Docker: docker run -d -p 27017:27017 mongo"
    echo ""
fi

# Check if .env exists
if [ ! -f "backend/.env" ]; then
    echo "❌ Error: backend/.env file not found"
    echo "   Please create it from backend/.env.example"
    echo "   And add your GEMINI_API_KEY"
    exit 1
fi

# Start backend
echo "🚀 Starting backend server on port 8001..."
cd backend
pip install -q -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8001 --reload &
BACKEND_PID=$!
cd ..

sleep 2

# Start frontend
echo "🚀 Starting frontend server on port 3000..."
cd frontend
python -m http.server 3000 &
FRONTEND_PID=$!
cd ..

sleep 2

echo ""
echo "================================================"
echo "✅ Servers are running!"
echo "================================================"
echo "Frontend: http://localhost:3000"
echo "Backend:  http://localhost:8001"
echo "API Docs: http://localhost:8001/docs"
echo ""
echo "Press Ctrl+C to stop all servers"
echo "================================================"

# Wait for Ctrl+C
trap "echo '\nStopping servers...'; kill $BACKEND_PID $FRONTEND_PID; exit" INT
wait